export const environment = {
    production: true,
    urlBase: 'https://api.sunat.gob.pe',
    base_url: 'http://localhost:3000/api' ,
    urlBaseIntranet: 'https://api-intranet.sunat.peru'
};
