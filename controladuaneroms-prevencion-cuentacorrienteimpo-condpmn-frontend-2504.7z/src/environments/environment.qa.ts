export const environment = {
  production: false,
  urlBase: 'https://api-test.sunat.gob.pe',
  urlBaseIntranet: 'https://api-intranet.sunat.peru'
};
