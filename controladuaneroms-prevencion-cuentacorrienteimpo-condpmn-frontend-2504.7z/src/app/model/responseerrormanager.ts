export class ResponseErrorManager {
  cod: string;
  msg: string;
  exc: string;
  constructor() { }
}
