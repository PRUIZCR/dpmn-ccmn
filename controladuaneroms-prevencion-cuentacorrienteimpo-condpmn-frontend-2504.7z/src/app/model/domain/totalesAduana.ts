import { DataCatalogo } from "../common/data-catalogo.model";
export interface totalesAduanas {
    concepto: DataCatalogo;
    cantidad: number;
}
