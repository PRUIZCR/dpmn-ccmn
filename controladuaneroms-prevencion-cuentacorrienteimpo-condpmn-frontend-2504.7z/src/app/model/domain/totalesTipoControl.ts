import { DataCatalogo } from "../common/data-catalogo.model";
export interface totalesTipoControl {
    concepto: DataCatalogo;
    cantidad: number;
}
