export class RowTblCompago {
  correlativo: number;
  numero: string;
  remitenteRuc: string;
  remitenteRazonSocial: string;
  motivoTraslado: string;
  destinatarioRuc: string;
  destinatarioRazonSocial: string;
  destino: string
}
