import { DataCatalogo } from "../common/data-catalogo.model";
export interface totalesEstado {
    concepto: DataCatalogo;
    cantidad: number;
}
