import { DataCatalogo } from "../common/data-catalogo.model";
export interface totalesFuncionarioAduanero {
    concepto: DataCatalogo;
    cantidad: number;
}
