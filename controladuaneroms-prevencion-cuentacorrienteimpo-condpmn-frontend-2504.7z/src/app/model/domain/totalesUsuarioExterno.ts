import { DataCatalogo } from "../common/data-catalogo.model";
export interface totalesUsuarioExterno {
    concepto: DataCatalogo;
    cantidad: number;
}
