export class CatalogoItem {
  codigo!: string;
  descripcion!: string;
}
