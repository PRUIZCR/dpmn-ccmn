import { DataCatalogo } from "../common/data-catalogo.model";

export class Conductor {
  pais!: DataCatalogo;
  tipoDocIdentidad!: DataCatalogo;
  numDocIdentidad!: string;
  nomConductor!: string;
  apeConductor!: string;
  numLicencia!: string;
}
