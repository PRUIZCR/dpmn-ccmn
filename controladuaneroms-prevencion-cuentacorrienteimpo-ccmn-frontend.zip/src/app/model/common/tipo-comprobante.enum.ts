export enum TipoComprobante {
  GUIA_REMISION = "GuiaRemision",
  CARTA_PORTE = "CartaPorte",
  BOLETA_FACTURA = "BoletaFactura"
}
