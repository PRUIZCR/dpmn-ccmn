export enum TipoControl {
  FISICO = "F",
  DOCUMENTARIO = "D",
  VERDE = "V",
  ROJO = "R",
  NARANJA = "N"
}
