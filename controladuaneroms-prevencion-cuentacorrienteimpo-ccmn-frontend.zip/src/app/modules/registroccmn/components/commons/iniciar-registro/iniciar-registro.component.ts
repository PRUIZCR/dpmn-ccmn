import { ChangeDetectorRef, Component, OnInit} from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { TipoRegistro } from 'src/app/model/common/tipo-registro';
import { PciDetalle } from 'src/app/model/domain/pcidetalle.model';
import { RegistroCcmnService } from 'src/app/services/registro-ccmn.service';

@Component({
  selector: 'app-iniciar-registro',
  templateUrl: './iniciar-registro.component.html',
  styleUrls: ['./iniciar-registro.component.css']
})
export class IniciarRegistroComponent implements OnInit {

  pasoActual : number = 1;
  controlPasoForm!: FormGroup;
  tipoRegistro!:TipoRegistro;
  estado=TipoRegistro;
  titulo!:string;

  constructor(private registroCcmnService: RegistroCcmnService,
              private formBuilder: FormBuilder,
              private cdRef:ChangeDetectorRef) {
    this.buildForm();
  }

  ngOnInit(): void {
    this.tipoRegistro = this.registroCcmnService.tipoRegistro;

    this.registroCcmnService.pasoActual$.subscribe( (numPaso : number) => {
        this.pasoActual = numPaso;
        this.cdRef.detectChanges();
    });
    this.completarDatosControlPaso();
  }

  get txtNumControlPaso() : AbstractControl {
    return this.controlPasoForm.get("controlPaso") as FormControl;
  }

  get txtFechaRegistro() : AbstractControl {
    return this.controlPasoForm.get("fechaRegistro") as FormControl;
  }

  get txtPaisPlaca() : AbstractControl {
    return this.controlPasoForm.get("paisPlaca") as FormControl;
  }

  get txtnumPlaca() : AbstractControl {
    return this.controlPasoForm.get("numPlaca") as FormControl;
  }

  get txtCanalControl() : AbstractControl {
    return this.controlPasoForm.get("canalControl") as FormControl;
  }

  private buildForm() : void {
    this.controlPasoForm = this.formBuilder.group({
      controlPaso: ['', [Validators.required]],
      fechaRegistro: ['', [Validators.required]],
      paisPlaca: ['', [Validators.required]],
      numPlaca: ['', [Validators.required]],
      canalControl: ['', [Validators.required]]
    });
  }

  private completarDatosControlPaso() : void {
    
    switch (this.tipoRegistro) {
      case "01":
          this.titulo = "Carga";
          break;
      case "02":
          this.titulo = "Buses";
          break;
      case "03":
          this.titulo = "Particulares";
          break;
      case "04":
          this.titulo = "CAF";
          break;
      case "05":
          this.titulo = "TTA";
          break;
      default:
          this.titulo = "";
          break;
  }
    
    let pci: PciDetalle = this.registroCcmnService.pciDetalle;

    if ( pci == null ) {
      return;
    }

    let numPciNew : string =  ('0000000000' + pci.numPci).slice(-10);

    let numCtrlPaso : string = pci?.aduana?.codDatacat + "-" + pci?.puestoControl?.codDatacat + "-" + pci.annPci + "-" + numPciNew;

    this.txtFechaRegistro.setValue(pci.fecInicioControl);
    this.txtNumControlPaso.setValue(numCtrlPaso);
    this.txtPaisPlaca.setValue(pci.paisPlaca.codDatacat);
    this.txtnumPlaca.setValue(pci.nomPlaca);
    this.txtCanalControl.setValue(pci.tipoControl.desDataCat);
  }

}
