import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {DropdownModule} from 'primeng/dropdown';
import {AccordionModule} from 'primeng/accordion';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthInterceptor } from './utils/auth.interceptor';
import { MensajeModalComponent } from './components/mensaje-modal/mensaje-modal.component';
import { DialogService } from 'primeng/dynamicdialog';


@NgModule({
  declarations: [
    AppComponent,
    MensajeModalComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    DropdownModule,
    AccordionModule,
    AppRoutingModule,
    HttpClientModule
  ],
  entryComponents: [
    MensajeModalComponent
  ],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }, DialogService],
  bootstrap: [AppComponent]
})
export class AppModule { }
