export enum Canal {
  ROJO = "R",
  NARANJA = "N",
  VERDE = "V"
}
