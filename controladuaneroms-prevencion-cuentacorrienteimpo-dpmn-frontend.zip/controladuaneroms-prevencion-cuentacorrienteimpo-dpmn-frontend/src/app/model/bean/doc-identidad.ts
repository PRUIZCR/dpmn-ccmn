import {DataCatalogo} from '../common/data-catalogo.model'

export class DocIdentidad {
  tipo : DataCatalogo;
  numero : string;
}
