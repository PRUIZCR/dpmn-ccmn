export class Dni {
  numero: string;
  nombres: string;
  apellidos: string;
}
