export class SaldoSerieDam {
  numSerie: number;
  cntSaldo: number;
  numSecDescarga: number;
}
