export class ConfigAduanaControl {
  codAduana: string;
  codPaisesFrontera: string[]
}
