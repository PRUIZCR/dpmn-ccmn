import { Participante } from '../bean/participante';
import { DataCatalogo } from '../common/data-catalogo.model';

export class Declaracion {
  codAduana: string;
  codRegimen: string;
  anio: number;
  numero: number;
  importador: Participante;
  canal: DataCatalogo;
  fechaNumeracion: string;
  fechaLevante: string;
  totalSeries: number;
  totalPesoBruto: number;
  totalPesoNeto: number;
}
