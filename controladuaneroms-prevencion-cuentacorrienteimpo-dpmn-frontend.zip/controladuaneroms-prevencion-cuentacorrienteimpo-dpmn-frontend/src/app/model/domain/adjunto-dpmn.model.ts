export class AdjuntoDpmn {
  codArchivoEcm: string;
  numCorrelativoDpmn: number;
  codTipoDocumento: string;
  desTipoDocumento: string;
  nomArchivo: string;
  nomContentType: string;
  fecRegistro: any;
  indEliminado: boolean;
}
