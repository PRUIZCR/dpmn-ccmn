export const environment = {
  production: false,
  urlBase: 'https://api-desa.sunat.gob.pe',
  urlBaseIntranet: 'https://api-intranet.sunat.peru'
};
