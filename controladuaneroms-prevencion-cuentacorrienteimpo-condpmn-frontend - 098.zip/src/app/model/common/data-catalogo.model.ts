export class DataCatalogo {
    codDatacat!: string;
    desDataCat!: string;
  
  }
  