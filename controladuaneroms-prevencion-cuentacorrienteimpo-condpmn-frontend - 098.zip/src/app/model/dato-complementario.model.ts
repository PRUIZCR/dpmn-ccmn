import { Ubigeo } from "./common/ubigeo.model";

export class DatoComplementario {
  ubigeoOrigen: Ubigeo = new Ubigeo;
  desObservacion!: string;
}
