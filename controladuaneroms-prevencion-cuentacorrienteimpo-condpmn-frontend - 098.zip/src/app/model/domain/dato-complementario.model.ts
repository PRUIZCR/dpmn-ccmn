import { Ubigeo } from "../common/ubigeo.model";

export class DatoComplementario {
  ubigeoOrigen: Ubigeo;
  desObservacion: string;
}
