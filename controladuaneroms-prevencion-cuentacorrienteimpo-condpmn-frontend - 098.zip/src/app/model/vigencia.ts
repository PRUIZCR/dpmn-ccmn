export class Vigencia {
  fecIniDispon!: Date;
  fecFinDisp!: Date;
  fecIniDisponText!: string;
  fecFinDispText!: string;
  constructor() { }
}
