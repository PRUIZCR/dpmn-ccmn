import { Component, OnInit} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TokenAccesoService } from './services/token-acceso.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'controladuaneroms-prevencion-cuentacorrienteimpo-condpmn-frontend';
  tipoOrigen : string;

  constructor(private activateRoute: ActivatedRoute,
    private router: Router,
    private tokenAccesoService: TokenAccesoService,) { }
  
  ngOnInit(): void {
    this.activateRoute.queryParams
    .subscribe(params => {
      if ( params.token != null ) {
        this.tokenAccesoService.guardarTokenSession(params.token);
       
        this.tipoOrigen = this.tokenAccesoService.origen;
       console.log('this.tipoOrigen: ' + this.tipoOrigen);
        if (this.tipoOrigen=='IA'){
          this.router.navigate(['/condpmn']);
        }else if(this.tipoOrigen=='IT'){
          this.router.navigate(['/iacondpmn']);
        }else{
          this.router.navigate(['/itcondpmn']);
        }


      }

      }
    );
  }
}
