import { Injectable } from '@angular/core';
import { ConstantesApp } from '../utils/constantes-app'
import {  environment } from 'src/environments/environment';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor() {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {

    if (request.url.indexOf(environment.urlBase) > -1) {
      const token: string = sessionStorage.getItem(ConstantesApp.KEY_SESSION_TOKEN) as string;
      const authReq = request.clone({ setHeaders: { Authorization: `Bearer ${token}` } });
      return next.handle(authReq);

    } else {
      return next.handle(request);
    }


  }
}
